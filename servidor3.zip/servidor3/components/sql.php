<?php

$servername = "localhost";
$username = "pantera";
$password = "cualquiera";
$dbname = "panteras";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

?>