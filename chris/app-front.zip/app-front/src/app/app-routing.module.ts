import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckoutComponent } from './com/checkout/checkout.component';
import { ListaComponent } from './com/lista/lista.component';
import { NotFoundComponent } from './com/not-found/not-found.component';
import { NuevoProductoComponent } from './com/nuevo-producto/nuevo-producto.component';

const routes: Routes = [
  {path: 'lista', component:ListaComponent},
  {path: 'nuevo', component:NuevoProductoComponent},
  {path: 'checkout', component:CheckoutComponent},
  {path: 'not-found', component:NotFoundComponent},
  {path: '', redirectTo: 'lista', pathMatch: 'full'},
  {path: '**', redirectTo: 'not-found'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
