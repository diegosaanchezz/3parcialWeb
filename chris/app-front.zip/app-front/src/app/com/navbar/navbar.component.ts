import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {

  cart_items:string = "";

  ngOnInit(): void {
    this.updateCart();
  }

  updateCart(){
    let cart:any = localStorage.getItem('cart');
    cart = cart == null? {} : JSON.parse(cart);

    let items = Object.keys(cart);

    if(items.length == 0){
      this.cart_items = "";
    } else {
      let x = 0;
      items.forEach(i => {
        x += cart[i].cantidad;
      })
      this.cart_items = "("+x+")";
    }

  }

}
