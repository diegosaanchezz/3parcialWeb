import { Component } from '@angular/core';
import { SqlService } from '../../srv/sql.service';

declare const $:any;
@Component({
  selector: 'app-nuevo-producto',
  templateUrl: './nuevo-producto.component.html',
  styleUrl: './nuevo-producto.component.css'
})
export class NuevoProductoComponent {

  constructor(private sql:SqlService){

  }

  agregarProducto(){
    let product = {
      "nombre":$('#nombre').val(),
      "precio":$('#precio').val(),
      "inventario":$('#inventario').val()
    }

    let r = this.sql.query(JSON.stringify(product), "insert");
    alert(r);

  }

}
