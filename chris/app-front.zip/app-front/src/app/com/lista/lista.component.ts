import { Component } from '@angular/core';
import { SqlService } from '../../srv/sql.service';

declare const $:any;

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrl: './lista.component.css'
})
export class ListaComponent {

  products:any=[];

  constructor(private sql:SqlService){

  }

  ngOnInit(): void {
    let r = this.sql.query("select * from Productos", "select");
    this.products = r.length>0 ? r:[];
  }

  addToCart(id: string){
    let cart:any = localStorage.getItem('cart');
    console.log(cart);
    if(cart == null){
      cart = {};
    } else {
      cart = JSON.parse(cart);
    }

    if(Object.keys(cart).indexOf(id) < 0){
      const {ID, ...product} = this.products.find((i:any) => i.ID == id);
      cart[id] = {cantidad: 0, ...product};
      console.log(cart[id]);
    }
    cart[id].cantidad++;
    localStorage.setItem('cart', JSON.stringify(cart));

    $('#update-cart').click();
  }
} 
