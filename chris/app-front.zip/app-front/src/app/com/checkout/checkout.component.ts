import { Component } from '@angular/core';

declare const $:any;

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent {

  ngOnInit(){
    this.showCart();
  }
  
  showCart(){
    let cart:any = localStorage.getItem('cart');
    if(cart == null){
      cart = {};
    } else {
      cart = JSON.parse(cart);
    }
 
    let tbodyContent = "";
    let total = 0;
    Object.keys(cart).forEach(i => {
      total += cart[i].cantidad * cart[i].Precio;
      tbodyContent += "<tr>";
      tbodyContent += `<td> ${cart[i].Nombre} </td>`;
      tbodyContent += "<td>"+cart[i].cantidad+"</td>";
      tbodyContent += "<td>"+cart[i].Precio+"</td>";
      tbodyContent += "<td>"+cart[i].cantidad * cart[i].Precio+"</td>";
      tbodyContent += "</tr>";
    })
    $('#tbody').html(tbodyContent);
    $('#total').html(total);

  }  

}
