import { Injectable } from '@angular/core';
import { JsonPipe } from '../../../node_modules/@angular/common/index';

declare const $:any;

@Injectable({
  providedIn: 'root'
})
export class SqlService {

  constructor() { }

  query(data:string, operator:string){
    let r:any = [];
    $.ajax({
      url:'http://localhost/web/app-back/server.php',
      method:'post',
      async:false,
      data:{
        'operation':operator,
        'query':data
      },
      success:(response:any)=>{
        r = JSON.parse(response);
      },
      error:(xhr:any,http:any,error:any)=>{
        console.error(error);
      },
    });
    return r;
  }

}
