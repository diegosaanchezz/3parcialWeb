import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './com/navbar/navbar.component';
import { ListaComponent } from './com/lista/lista.component';
import { NotFoundComponent } from './com/not-found/not-found.component';
import { NuevoProductoComponent } from './com/nuevo-producto/nuevo-producto.component';
import { CheckoutComponent } from './com/checkout/checkout.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ListaComponent,
    NotFoundComponent,
    NuevoProductoComponent,
    CheckoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
