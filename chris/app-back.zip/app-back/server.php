<?php

    // Allow CORS for all domains
    header("Access-Control-Allow-Origin: *");
    // Allow specific HTTP methods
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    // Allow specific headers
    header("Access-Control-Allow-Headers: Content-Type, Authorization");

    // Handle preflight requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS'){
        // If it's a preflight request, respond with status 200
        http_response_code(200);
        exit;
    }

    $servername = "localhost";
    $username = "pantera";
    $password = "pantera12345";
    $dbname = "panteras";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("500 - Connection failed: " . $conn->connect_error);
    }

    include 'operations/'.$_POST['operation'].'.php';

?>