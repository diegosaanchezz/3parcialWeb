<?php

    $data = json_decode($_POST["query"], true);

    $query =  "insert into Productos (Nombre, Precio, Inventario) ";
    $query .= "values ('".$data['nombre']."',".$data['precio'].",".$data['inventario'].")";

    $result = $conn->query($query);

    if ($result === false) {
        echo "400";
    } else {
        echo "200";
    }

?>